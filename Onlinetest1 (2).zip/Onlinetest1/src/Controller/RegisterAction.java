package Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

//User Register Controller
@Controller
@RequestMapping("register")
public class RegisterAction
{
	HiberAction db=new HiberAction();	
	@Autowired
	UserBean userbean;
	public UserBean getUserbean() {
		return userbean;
	}

	public void setUserbean(UserBean userbean) {
		this.userbean = userbean;
	}
// Get Method
// Set View Name As Register Page to Go Register Form
	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView Register1()
	{
		UserBean userbean=new UserBean();
		ModelAndView mandv=new ModelAndView();
		mandv.setViewName("Register");
		mandv.addObject("userbean",userbean);
		return mandv;
		
	}

// User Register in database can Done in Post Method

@RequestMapping(method=RequestMethod.POST)
public ModelAndView Register(UserBean userbean)
{
	ModelAndView mandv=new ModelAndView();
	String username=userbean.getUsername().toString().trim();
	String password=userbean.getPassword().toString().trim();
	//System.out.println(password);
	// Check the User Name in database if it is true
	if(db.checkuser(username,password))
	{
		System.out.println("user exist");
		mandv.setViewName("clientlogin");
	}
	// User name is not Available
	else
	{
		//Register The user Name And Password in  User Daatabase
		
		db.Register(username,password);
		System.out.println("register success");
		mandv.setViewName("clientlogin");
	}
	
	mandv.addObject("userbean",userbean);
	
	return mandv;
	
}  
}