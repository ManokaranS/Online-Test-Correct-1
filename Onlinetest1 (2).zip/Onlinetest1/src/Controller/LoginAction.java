package Controller;

import javax.servlet.http.HttpSession;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

//Client Login  Controller
@Controller
@RequestMapping("clientlogin")
public class LoginAction
{   
	
	@Autowired
	UserBean userbean;
	public UserBean getUserbean() {
		return userbean;
	}

	public void setUserbean(UserBean userbean) {
		this.userbean = userbean;
	}
	
	//Client Login  form get Mathod and set view name as login page
	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView getmethod()
	{
		UserBean userbean=new UserBean();
		ModelAndView mandv=new ModelAndView();
		mandv.setViewName("clientlogin");
		mandv.addObject("userbean",userbean);
		return mandv;
	}
	
//	Client Login User name and password Check And Authenticate the user
	@RequestMapping(method=RequestMethod.POST)
	public ModelAndView execute(UserBean userbean,HttpSession session)
	{
		ModelAndView mandv=new ModelAndView();
		HiberAction dba=new HiberAction();
		String username=userbean.getUsername().toString().trim();
		String password=userbean.getPassword().toString().trim();
		System.out.println("hi check user"+username+password);
		//Check user method 
	 if(dba.checkuser(username,password))
					{
		 			//	Check the status login or logout
						if(dba.checkstatus(username))
							{System.out.println("sorry friend");
							dba.changestatus(username, 1);
							session.setAttribute("username",username);
							System.out.println("hi");
							mandv.setViewName("welcome");
							}
						else
							{
					// User Already Login
						System.out.println("Login Already Login.AlreadyLogin");
						session.setAttribute("username",username);
						mandv.setViewName("welcome");
							}
					}
	 // 	User name Is Not Available
				else{
					System.out.println("hi i am here");
					session.setAttribute("username",username);
					mandv.setViewName("Register");
				}
	mandv.addObject("userbean",userbean);
	return mandv;

}
	
}
