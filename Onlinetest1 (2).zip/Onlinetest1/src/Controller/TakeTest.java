package Controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import Controller.SessionUtility;

// Controller for Attend the test

@Controller
@RequestMapping("taketest")
public class TakeTest {

public List<QuestionBean> questions=new ArrayList<QuestionBean>();
public int count;
public int mark;
@Autowired
QuestionBean questionbean;
		public QuestionBean getQuestionbean() {
	return questionbean;
}
public void setQuestionbean(QuestionBean questionbean) {
	this.questionbean = questionbean;
}
ResultBean resultBean;
public ResultBean getResultBean() {
	return resultBean;
}
public void setResultBean(ResultBean resultBean) {
	this.resultBean = resultBean;
}
Session session=SessionUtility.GetSessionConnection();

//		Get method for Query the questions From table and add it in Result
		@RequestMapping(method=RequestMethod.GET)
		public ModelAndView getmethod(HttpSession session1)
		{
			
			QuestionBean questionbean=new QuestionBean();
			ModelAndView mandv=new ModelAndView();
			String hql = "FROM QuestionBean";
			Query query = session.createQuery(hql);
			@SuppressWarnings("unchecked")
			List<QuestionBean> results = query.list();
			questions=results;
			session1.setAttribute("Marks",0);
			session1.setAttribute("size", questions.size());
			mandv.setViewName("takeTest");
			mandv.addObject("question",questions.get(0));
			count++;
			if (count<questions.size()) {
				mandv.addObject("nextquestion",count);
			}
			else
			{
				mandv.addObject("nextquestion","result");
			}
			mandv.addObject("questionbean",questionbean);
			
			return mandv;
		
		}
		
//		User Can View the Question one by one using post method

		@RequestMapping(method=RequestMethod.POST)
		public ModelAndView execute(HttpSession session,QuestionBean questionBean)
		{
			
			ModelAndView dl=new ModelAndView();
			
			int size=Integer.parseInt( session.getAttribute("size").toString().trim());
			// Check the User can click the option button
			if(questionBean.getUser_ans()==null)
			{
				dl.setViewName("error");
			}
			else{
				// Check the User Can A finish the test or not !
						if(!questionBean.getNext_qus().toString().equalsIgnoreCase("result"))
					
						{
							dl.addObject("question",questions.get(count));
							dl.addObject("questionbean",new QuestionBean());
					
									count++;
									if(count<questions.size())
									{
										dl.addObject("nextquestion",count);
									}else
									{
										dl.addObject("nextquestion","result");
									}
						
						dl.setViewName("takeTest");
						}
				//	user can finish the test
						else
						{
							dl.setViewName("result");
							dl.addObject("resultbean",resultBean);
						}
			}
			// Check User can Click the Answer
			if(questionBean.getUser_ans()==null)
			{
				dl.setViewName("error");
			}
			else{
			//	Calculate The Marks And Add the result in Session
				if(questionBean.getUser_ans().toString().equalsIgnoreCase(questionBean.getAnswer()))
				{
					if(mark <= size)
					{
					int mark=Integer.parseInt(session.getAttribute("Marks").toString())+1;
					session.setAttribute("Marks", mark);
					}
				}
			}
			return dl;
		
	}
		
}

