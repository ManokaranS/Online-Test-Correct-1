package Controller;

import org.springframework.stereotype.Controller;

// POJO Class For Result database
@Controller
public class ResultBean 
{
private int tid;
private String studentName;
private String testName;
private int marks;

//Getters and Setters for Result database Parameter
public int getTid() {
	return tid;
}
public void setTid(int tid) {
	this.tid = tid;
}

public String getTestName() {
	return testName;
}
public void setTestName(String testName) {
	this.testName = testName;
}

public int getMarks() {
	return marks;
}
public void setMarks(int marks) {
	this.marks = marks;
}
public String getStudentName() {
	return studentName;
}
public void setStudentName(String studentName) {
	this.studentName = studentName;
}
}
