package Controller;


import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

// User Logout Controller
@Controller
@RequestMapping("logout")
public class LogoutAction{
	
	HiberAction dba=new HiberAction();
// 	User Logout Controller Process
	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView execute1(HttpSession session) {
		ModelAndView mandv=new ModelAndView();
		System.out.println("logout");
		String uname=session.getAttribute("username").toString();
		System.out.println("logout 1");
		//Check The User name is Null or Not
	     if(uname!=null)
	     {
	    	 if(dba.checkstatus(uname))
	    	 {
	    	// Change The User Status From Online to Offline
			dba.changestatus(uname,0);
			System.out.println("Status change success logout success");
			session.invalidate();
			mandv.setViewName("index");
	    	 }
	    	// Already Logout User
	    	 else
	    	 {
	    		 session.invalidate();
		    	 mandv.setViewName("already"); 
	    	 }
	     }
	    // Session uname Not Available
	     else
	     {
	    	 session.invalidate();
	    	 mandv.setViewName("already");
	     }
			return mandv;
	}
	@RequestMapping(method=RequestMethod.POST)
	public ModelAndView execute(HttpSession session) 
	{
		
		ModelAndView mandv=new ModelAndView();		
		
		String uname=session.getAttribute("username").toString();
	
		//Check The User name is Null or Not
	     if(uname!=null)
	     { 
	    	//	Check the Status of user before Changing the Status 
		    if(!dba.checkstatus(uname))
	    	 {
	    	// Change The User Status From Online to Offline
			dba.changestatus(uname,0);
			System.out.println("Status change success logout success");
			session.invalidate();
			mandv.setViewName("index");
	    	 }
	    	 else
	    	 {
	    		 
		    	 mandv.setViewName("already"); 
	    	 }
	     }
	     // Session uname Not Available
	     else
	     {
	    	 session.invalidate();
	    	 mandv.setViewName("already");
	     }
			return mandv;
	}
}
