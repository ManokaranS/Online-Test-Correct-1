package Controller;

import org.springframework.stereotype.Controller;


//POJO Class for User Tables 
@Controller
public class UserBean 
{

private int  uid;
private int status;

// Getters And Setters for user Table

public int getUid() {
	return uid;
}
public void setUid(int uid) {
	this.uid = uid;
}
public int getStatus() {
	return status;
}
public void setStatus(int status) {
	this.status = status;
}
private String username;
private String password;
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
}
