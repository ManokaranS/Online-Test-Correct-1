package Controller;


import javax.servlet.http.HttpSession;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("adminlogin")
public class AdminLogin
{   
	/*Admin Authentication */
	@Autowired
	AdminEntity adminEntity;

	public AdminEntity getAdminEntity() {
		return adminEntity;
	}
	public void setAdminEntity(AdminEntity adminEntity) {
		this.adminEntity = adminEntity;
	}
	/*Admin Authentication Login screen Page Get Method*/
	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView getmethod()
	{
		AdminEntity adminEntity=new AdminEntity();
		ModelAndView mandv=new ModelAndView();
		mandv.setViewName("loginAdmin");
		mandv.addObject("adminEntity",adminEntity);
		return mandv;
	}
	/*Admin Authentication Checking Here */
	@RequestMapping(method=RequestMethod.POST)
	public ModelAndView execute(AdminEntity adminEntity,HttpSession session)
	{
		ModelAndView mandv=new ModelAndView();
		AdminAction dba=new AdminAction();
		String adminName=adminEntity.getAdminName().toString().trim();
		String adminPassword=adminEntity.getAdminPassword().toString().trim();
		System.out.println("hi check user"+adminName+adminPassword);
		//Check the Admin Name And password in database
		if(dba.checkAdmin(adminName,adminPassword))
					{
			//Check the Admin Status Here
						if(dba.checkAdminStatus(adminName))
							{
						//Change The Admin Status Offline To Online
							dba.changeAdminStatus(adminName, 1);
						
							session.setAttribute("adminName",adminName);
						
							mandv.setViewName("welcom1");
							}
						else
							{
							//Admin can already login
						System.out.println("Login Already Login.AlreadyLogin");
						session.setAttribute("adminName",adminName);
						mandv.setViewName("welcom1");
							}
					}
				else{
					//Admin Name and password can't match 
					session.setAttribute("adminName",adminName);
					mandv.setViewName("errorAdmin");
				}
	mandv.addObject("adminEntity",adminEntity);
	return mandv;

}
	
}
