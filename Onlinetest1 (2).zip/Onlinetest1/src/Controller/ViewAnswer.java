package Controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import Controller.SessionUtility;

//Controller for View Answer
@Controller
@RequestMapping("viewAnswer")
public class ViewAnswer {


@Autowired
QuestionBean questionbean;
		public QuestionBean getQuestionbean() {
	return questionbean;
}
public void setQuestionbean(QuestionBean questionbean) {
	this.questionbean = questionbean;
}

Session session=SessionUtility.GetSessionConnection();

	//	Get Method For to view the Question 
		@RequestMapping(method=RequestMethod.GET)
		public ModelAndView getmethod(HttpSession session1)
		{
			
			QuestionBean questionbean=new QuestionBean();
			ModelAndView mandv=new ModelAndView();
			String hql = "FROM QuestionBean";
			Query query = session.createQuery(hql);
			@SuppressWarnings("unchecked")
			List<QuestionBean> results = query.list();
			mandv.setViewName("viewAnswer");
			mandv.addObject("question",results);
			mandv.addObject("questionbean",questionbean);
			return mandv;
		
		}	
}

