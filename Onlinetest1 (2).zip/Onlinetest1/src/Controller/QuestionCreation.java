package Controller;

import org.hibernate.Session;

// Create A Question and Save the Question into Database
public class QuestionCreation {

	Session session;
	public boolean questionCreate(int questionNO,String question,String option1,String option2,String option3,String option4,String answer)
	{
		 session=SessionUtility.GetSessionConnection(); 
		QuestionBean questionbean=new QuestionBean();
		
		// Save All the parameters into Table
		
		questionbean.setQuestionNO(questionNO);
		questionbean.setQuestion(question); 
		questionbean.setOption1(option1);
		questionbean.setOption2(option2);
		questionbean.setOption3(option3);
		questionbean.setOption4(option4);
		questionbean.setAnswer(answer);
		 try{
		//		Save The Object in Database
		 session.save(questionbean);	 
		 SessionUtility.closeSession(null);	 
		 return true;
		 }
		 catch(Exception e1)
		 {
			 System.out.println("failed insert"+e1);
			 return false;
		 }

	}
}
