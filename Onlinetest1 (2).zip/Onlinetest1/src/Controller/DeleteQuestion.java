package Controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import Controller.SessionUtility;


@Controller
@RequestMapping("deletequestion")
public class DeleteQuestion {
//Delete The Question From Question from Question Table
	
public static List<QuestionBean> questions=new ArrayList<QuestionBean>();
public static int count;
@Autowired
QuestionBean questionbean;
		public QuestionBean getQuestionbean() {
	return questionbean;
}
public void setQuestionbean(QuestionBean questionbean) {
	this.questionbean = questionbean;
}

Session session=SessionUtility.GetSessionConnection();
//Get The Question From Question From database and ADD to List

		@RequestMapping(method=RequestMethod.GET)
		public ModelAndView getmethod(HttpSession session1)
		{
			
			QuestionBean questionbean=new QuestionBean();
			ModelAndView mandv=new ModelAndView();
			String hql = "FROM QuestionBean";
			Query query = session.createQuery(hql);
			@SuppressWarnings("unchecked")
			List<QuestionBean> results = query.list();
			questions=results;
			session1.setAttribute("Marks",0);
			
			mandv.setViewName("deletequestion");
			mandv.addObject("question",questions.get(0));
			count++;
			if (count<questions.size()) {
				mandv.addObject("nextquestion",count);
				session1.setAttribute("size", questions.size());
			}
			else
			{
				mandv.addObject("nextquestion","result");
			}
			mandv.addObject("questionbean",questionbean);
			
			return mandv;
		
		}
		//To display the Question from List one by one and Delete The Question
		@RequestMapping(method=RequestMethod.POST)
		public ModelAndView execute(HttpSession session,QuestionBean questionBean)
		{
			QuestionBean question=new QuestionBean();
			ModelAndView dl=new ModelAndView();
			AdminAction adminaction=new AdminAction();
			int questionNO=question.getQuestionNO();
					
			if(!questionBean.getNext_qus().toString().equalsIgnoreCase("viewquestion"))
				{
					dl.addObject("question",questions.get(count));
					dl.addObject("questionbean",new QuestionBean());
					
					count++;
					if(count<questions.size())
					{
						dl.addObject("nextquestion",count);
					}else
					{
						dl.addObject("nextquestion","viewquestion");
					}
				
				dl.setViewName("deletequestion");
				}
			else
			{
				dl.setViewName("viewquestion");
			}
			adminaction.deletequestion(questionNO);
			return dl;
		
	}
		
}

