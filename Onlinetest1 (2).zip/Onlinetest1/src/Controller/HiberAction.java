package Controller;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import Controller.SessionUtility;
import Controller.UsersEntity;

public class HiberAction {
Session session;
	// Check the User Name and Password In Database 
	public boolean checkuser(String username,String password)
	{
		 session=SessionUtility.GetSessionConnection();
		
		String hql = "FROM UsersEntity where username = :username and password = :password";
		
		Query query = session.createQuery(hql);
		
		query.setParameter("username",username);
		query.setParameter("password", password);
		@SuppressWarnings("unchecked")
		List<UsersEntity> results = query.list();
		
		Iterator<UsersEntity> it=results.iterator();
		
		if (it.hasNext()) {
			System.out.println("username Checked");
			return true;
		}
		else
		{
			System.out.println("username check failed");
		return false;
		}
	
	}
	
	// Change The status from Login to logout and vice versa
	public boolean changestatus(String uname,int status)
	{
		 session=SessionUtility.GetSessionConnection();
		
		Query query = session.createQuery("update UsersEntity set status = :statusval where username = :unameval");
		
		query.setParameter("statusval",status);
		query.setParameter("unameval",uname);
		
		if (query.executeUpdate()==1) {
			System.out.println("status "+uname);
			SessionUtility.closeSession(null);
			return true;
		}
		else
		{
			return false;
		}
		
		
		
	}
	
// Check The status of the User i.e, Login Or Logout	
	public boolean checkstatus(String uname)
	{
		
		 session=SessionUtility.GetSessionConnection();
		
		String hql = "FROM UsersEntity where username = :username";
		
		Query query = session.createQuery(hql);
		
		query.setParameter("username",uname);
		
		@SuppressWarnings("unchecked")
		List<UsersEntity> results = query.list();	
		Iterator<UsersEntity> it=results.iterator();
		UsersEntity un=it.next();
		if (un.getStatus()==1) {
			System.out.println("status 1");
			return false;
		}
		else
		{
		System.out.println("status 0");
		return true;
		}
		
	}
	


//	Check the User name In database
	public boolean checkuser(String username)
	{
		 session=SessionUtility.GetSessionConnection();
		
		String hql = "FROM UsersEntity where username = :username";
		
		Query query = session.createQuery(hql);
		
		query.setParameter("username",username);
	
		@SuppressWarnings("unchecked")
		List<UsersEntity> results = query.list();
		
		Iterator<UsersEntity> it=results.iterator();
		
		if (it.hasNext()) {
			System.out.println("username Checked");
			return true;
		}
		else
		{
			System.out.println("username check failed");
		return false;
		}
	
	}

//	Register As a New User Giving User Name And Password
	public boolean Register(String uname,String password)
	{
		 session=SessionUtility.GetSessionConnection(); 
		 UsersEntity e=new UsersEntity();
		
		 e.setUsername(uname);
		 e.setPassword(password);
		 e.setStatus(0);
		 
		 try{
		 session.save(e);	 
		 SessionUtility.closeSession(null);
		 
		 return true;
		 }
		 catch(Exception e1)
		 {
			 System.out.println("failed insert"+e1);
			 return false;
		 }

	}

//	Store The Test Result marks And Student Name in result database
	public boolean storeResult(String studentName, String testName, int marks) {
		session=SessionUtility.GetSessionConnection(); 
		ResultBean resultbean=new ResultBean();
		resultbean.setStudentName(studentName);
		resultbean.setTestName(testName);
		resultbean.setMarks(marks);
		try{
			 session.save(resultbean);	 
			 SessionUtility.closeSession(null);
			 
			 return true;
			 }
			 catch(Exception e1)
			 {
				 System.out.println("failed insert  "+e1);
				 return false;
			 }
	}

//	Check The Result of the user in Result Database
	public boolean checkresult(String studentName) 
	{
		 session=SessionUtility.GetSessionConnection();
			
			String hql = "FROM ResultBean where studentName = :studentName";
			
			Query query = session.createQuery(hql);
			
			query.setParameter("studentName",studentName);
		
			@SuppressWarnings("unchecked")
			List<ResultBean> results = query.list();
			
			Iterator<ResultBean> it=results.iterator();
			
			if (it.hasNext()) {
				System.out.println("username Checked");
				String StudentName=it.next().toString().trim();
				System.out.println(StudentName);
				return true;
			}
			else
			{
				System.out.println("username check failed");
			return false;
			}
		
		
	}
	
	

// Get the Particular Student result from database. Save the result in List and Return the List
	public List<ResultBean> checkList(String studentName) 
	{
		 session=SessionUtility.GetSessionConnection();
			
			String hql = "FROM ResultBean where studentName = :studentName";
			
			Query query = session.createQuery(hql);
			
			query.setParameter("studentName",studentName);
		
			@SuppressWarnings("unchecked")
			List<ResultBean> results = query.list();
			
			Iterator<ResultBean> it=results.iterator();
			
			if (it.hasNext()) {
				System.out.println("username Checked");
				String StudentName=it.next().toString().trim();
				System.out.println(StudentName);
				return results;
			}
			else
			{
				System.out.println("username check failed");
			return null;
			}
		
		
	}
	
	
	/* Main Function To Test the Method Written above
	 * 
	 * 	
	public static void main(String[] args) {
		HiberAction h=new HiberAction();
		System.out.println(h.checkuser("guna", "root"));
		System.out.println(h.checkstatus("guna"));
		System.out.println(h.changestatus("guna", 0));
		System.out.println(h.Register("mano", "secret", 0));
	}
	
	*
	*/
}
