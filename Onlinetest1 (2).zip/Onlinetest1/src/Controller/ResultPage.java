package Controller;

import javax.servlet.http.HttpSession;


import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

//Controller  for get The Result from session

@Controller
@RequestMapping("resultPage")
public class ResultPage {


@Autowired
ResultBean resultbean;

public ResultBean getResultbean() {
	return resultbean;
}
public void setResultbean(ResultBean resultbean) {
	this.resultbean = resultbean;
}
Session session=SessionUtility.GetSessionConnection();

//Get Method To Display the view as result Page
		@RequestMapping(method=RequestMethod.GET)
		public ModelAndView getmethod()
		{
			
			ModelAndView mandv=new ModelAndView();
			mandv.addObject("resultBean",resultbean);	
			mandv.setViewName("result");
			return mandv;
		}
		
//		Diaplay the Result from Session And Store the Result in database
		@RequestMapping(method=RequestMethod.POST)
		public ModelAndView getmethod1(HttpSession session1,ResultBean resultbean)
		{
			ModelAndView mandv=new ModelAndView();
			System.out.println(session1.getAttribute("Marks"));
			String StudentName=session1.getAttribute("username").toString().trim();
			String TestName="DefaultTest";
			int marks=Integer.parseInt(session1.getAttribute("Marks").toString().trim());
			HiberAction Haction=new HiberAction();
			System.out.println(marks);
			System.out.println(StudentName);
			// Check the user has already attend the test
			if(Haction.checkresult(StudentName)){
				mandv.setViewName("error");
			}
			// User New to the Particular Test Then Update The result table
			else{
				mandv.setViewName("result2");
				Haction.storeResult(StudentName,TestName,marks);
			session1.setAttribute("studentName", StudentName);
			}
			mandv.addObject("reultBean",resultbean);
			return mandv;
			
		}
		
}