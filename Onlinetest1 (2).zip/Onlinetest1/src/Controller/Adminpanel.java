package Controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


@Controller
@RequestMapping("adminpanel")
public class Adminpanel {
//Create A Question And Update The Question Database
	
// Bean Class Autowired
@Autowired
QuestionBean questionbean;

	public QuestionBean getQuestionbean() {
	return questionbean;
}
public void setQuestionbean(QuestionBean questionbean) {
	this.questionbean = questionbean;
}
//Go to the Enter Question Admin Form 
	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView getmethod()
	{
		QuestionBean questionbean=new QuestionBean();
		ModelAndView mandv=new ModelAndView();
		mandv.setViewName("enterquestion");
		mandv.addObject("questionbean",questionbean);
		return mandv;
	}
	//Get The Questions And Options And Store to Question Database
	@RequestMapping(method=RequestMethod.POST)
	public ModelAndView execute(HttpSession session,QuestionBean questionBean)
	{
		QuestionBean questionbean=new QuestionBean();
		ModelAndView mandv=new ModelAndView();
		QuestionCreation questionCreate=new QuestionCreation();
		
		
		int questionNO=questionBean.getQuestionNO();
		
		String question=questionBean.getQuestion().toString().trim();
		String option1=questionBean.getOption1().toString().trim();
		String option2=questionBean.getOption2().toString().trim();
		String option3=questionBean.getOption3().toString().trim();
		String option4=questionBean.getOption4().toString().trim();
		String answer=questionBean.getAnswer().toString().trim();
		
		questionCreate.questionCreate(questionNO, question, option1, option2, option3, option4, answer);
		
		mandv.setViewName("enterquestion");
		mandv.addObject("questionbean",questionbean);
		return mandv;
}
}
