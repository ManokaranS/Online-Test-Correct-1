package Controller;

import org.springframework.stereotype.Controller;

@Controller
public class AdminEntity {

	/* Admin Table POJO Class */
	private int aid;
	private String adminName;
	private String adminPassword;
	private int status;
	/* Admin table Getters and Setters */
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	public String getAdminName() {
		return adminName;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public String getAdminPassword() {
		return adminPassword;
	}
	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	
}
