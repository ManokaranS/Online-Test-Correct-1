package Controller;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import Controller.SessionUtility;
import Controller.AdminEntity;

public class AdminAction {
Session session;
	/* Admin Name and Password Checking */
	public boolean checkAdmin(String adminName,String adminPassword)
	{
		 session=SessionUtility.GetSessionConnection();
		
		String hql = "FROM AdminEntity where adminName = :adminName and adminPassword = :adminPassword";
		
		Query query = session.createQuery(hql);
		
		query.setParameter("adminName",adminName);
		query.setParameter("adminPassword", adminPassword);
		@SuppressWarnings("unchecked")
		List<AdminEntity> results = query.list();
		
		Iterator<AdminEntity> it=results.iterator();
		
		if (it.hasNext()) {
			//System.out.println("username Checked");
			return true;
		}
		else
		{
			//System.out.println("username check failed");
		return false;
		}
	
	}
	
	/* Change the admin status from logout to login vice versa */
	
	public boolean changeAdminStatus(String adminName,int status)
	{
		 session=SessionUtility.GetSessionConnection();
		
		Query query = session.createQuery("update AdminEntity set status = :statusval where adminName = :adminName");
		
		query.setParameter("statusval",status);
		query.setParameter("adminName",adminName);
		
		if (query.executeUpdate()==1) {
			
			SessionUtility.closeSession(null);
			return true;
		}
		else
		{
			return false;
		}		
	}
	
	/* Admin status is checked here to know about login or logout */
	public boolean checkAdminStatus(String adminName)
	{
		
		 session=SessionUtility.GetSessionConnection();
		
		String hql = "FROM AdminEntity where adminName = :adminName";
		
		Query query = session.createQuery(hql);
		
		query.setParameter("adminName",adminName);
		
		@SuppressWarnings("unchecked")
		List<AdminEntity> results = query.list();	
		Iterator<AdminEntity> it=results.iterator();
		AdminEntity un=it.next();
		if (un.getStatus()==1) {
			// System.out.println("status 1");
			return false;
		}
		else
		{
		System.out.println("status 0");
		return true;
		}
		
	}	
	/* checking Code Main menu*/
//public static void main(String[] args) {
//	AdminAction h=new AdminAction();
//	System.out.println(h.Register("mano", "secret", 0));
//	System.out.println(h.deletequestion(3));
//}
/* To delete a question from Database */
	public boolean deletequestion(int questionNO) {
session=SessionUtility.GetSessionConnection();
		QuestionBean questionBean=new QuestionBean();
		String hql = "Delete from QuestionBean where questionNO= :questionNO";
		
		Query query = session.createQuery(hql);
		
		query.setInteger("questionNO",questionNO);
		int result=query.executeUpdate();
		session.delete(questionBean);
		System.out.println("result "+result);
		try{
			 SessionUtility.closeSession(null);
			 return true;
			 }
			 catch(Exception e1)
			 {
				 System.out.println("failed insert"+e1);
				 return false;
			 }
		
	}

}
