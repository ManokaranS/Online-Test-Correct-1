package Controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


@Controller
@RequestMapping("adminlogout")
public class AdminLogout {
//Admin Logout Controller Get Method
		AdminAction adminaction=new AdminAction();
		@RequestMapping(method=RequestMethod.GET)
		public ModelAndView execute1(HttpSession session) {
			ModelAndView mandv=new ModelAndView();
			//System.out.println("logout");
			String adminName=session.getAttribute("adminName").toString();
			//System.out.println("logout 1");
			//Check Admin Name
		     if(adminName!=null)
		     {
		    	 	//Change the Admin Status Login To Logout
		    		 adminaction.changeAdminStatus(adminName, 0);
		 			System.out.println("Status change success logout success");
		 			//Store the Status in database close the session
		 			session.invalidate();
		 			mandv.setViewName("index"); 
		    	 
				
		     }
		     else{
		    	 session.invalidate();
		    	 mandv.setViewName("already");
		     }
				return mandv;
		}
		//Admin Logout Controller Post Method	
	@RequestMapping(method=RequestMethod.POST)
	public ModelAndView execute(HttpSession session) {
		ModelAndView mandv=new ModelAndView();
	
		String adminName=session.getAttribute("adminName").toString();
	
	//	Check Admin Name
	     if(adminName!=null)
	     {
	    	 //Change Admin status
	    		 adminaction.changeAdminStatus(adminName, 0);
	 			System.out.println("Status change success logout success");
	 			session.invalidate();
	 			mandv.setViewName("index"); 
	     }
	     else{
	    	 session.invalidate();
	    	 mandv.setViewName("already");
	     }
			return mandv;
	}
}