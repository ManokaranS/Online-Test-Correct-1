package Controller;

import java.util.ArrayList;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

//Controller For Display the result

@Controller
@RequestMapping("resultDisplay")
public class ResultDisplay {

	public List<QuestionBean> result=new ArrayList<QuestionBean>();
@Autowired
ResultBean resultBean;

public ResultBean getResultBean() {
	return resultBean;
}

public void setResultBean(ResultBean resultBean) {
	this.resultBean = resultBean;
}
Session session=SessionUtility.GetSessionConnection();

// Get Method for Set The View Name as Result Page
@RequestMapping(method=RequestMethod.GET)
public ModelAndView getmethod()
{
	
	ResultBean resultBean=new ResultBean();
	ModelAndView mandv=new ModelAndView();

	mandv.setViewName("result2");

	mandv.addObject("resultBean",resultBean);
	return mandv;
	
}

//	Display The Result For the Particular User

@RequestMapping(method=RequestMethod.POST)
public ModelAndView getmethod(HttpSession session1,ResultBean resultBean)
	{
	
	ModelAndView mandv=new ModelAndView();
	String studentName=session1.getAttribute("username").toString().trim();
	System.out.println(studentName);
	HiberAction haction=new HiberAction();
// Store the Result in a list
	List<ResultBean> results=haction.checkList(studentName);
	mandv.setViewName("result2");
	mandv.addObject("results",results);
	mandv.addObject("resultBean",resultBean);
return mandv;
}
}
